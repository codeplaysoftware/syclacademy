cd lab
dpcpp -fintelfpga hough_transform_local_mem.cpp -Xshardware -Xsprofile -o hough_transform_local_mem.fpga
