./bin/hough_transform_local_mem.fpga
