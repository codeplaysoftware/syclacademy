dpcpp -fintelfpga ./lab/hough_transform_local_mem.cpp -Xshardware -Xsprofile -o ./bin/hough_transform_local_mem.fpga
