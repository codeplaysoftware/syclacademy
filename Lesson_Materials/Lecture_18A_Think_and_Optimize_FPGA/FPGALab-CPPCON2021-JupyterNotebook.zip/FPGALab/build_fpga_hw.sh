#!/bin/bash
source /opt/intel/oneapi/setvars.sh > /dev/null 2>&1
dpcpp -fintelfpga ./lab/hough_transform_local_mem.cpp -Xshardware -Xsboard=intel_s10sx_pac:pac_s10 -Xsprofile -o ./bin/hough_transform_local_mem.fpga
